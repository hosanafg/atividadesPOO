package operadores_ternarios;

public class OperadoresTernarios{
	
	public static void main(String[] args) {
		int x=80;
		//x++;
		float y=((x%2)==0)?(x/2):(3*x)+1;
		System.out.println("y="+y);
	}
}
