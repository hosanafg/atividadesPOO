package tipos_de_variaveis;

public class TiposdeVariaveis {
	
	public static int varClasse=5;
	public int varObjeto=100;
	
	public static void main(String[] args) {
		//int varLocal=10;
		
		TiposdeVariaveis v1 = new TiposdeVariaveis();
		TiposdeVariaveis v2 = new TiposdeVariaveis();
		
		//valores antes da modificação
		System.out.println(v1.varClasse);
		System.out.println(v1.varObjeto);
		
		//incremento de +1 na classe com o objeto v1 também reflete no objeto v2
		v1.varClasse++;
		System.out.println(v2.varClasse);
		
		//incremento de +1 no objeto v1 não reflete no objeto v2
		v1.varObjeto++;
		System.out.println(v2.varObjeto);
		System.out.println(v1.varObjeto);
	}

}
