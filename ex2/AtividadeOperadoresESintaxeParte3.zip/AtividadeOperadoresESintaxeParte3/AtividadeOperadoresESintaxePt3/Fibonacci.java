import java.util.Scanner;
public class Fibonacci {
    public static void main(String[] args) {
        Scanner valorlimite = new Scanner(System.in);
        System.out.print("Digite o limite p/ sequência de Fibonacci: ");
        int limite=valorlimite.nextInt();

        int anterior=0;
        int atual=1;
        
        if(limite>0) {
            System.out.print(anterior+"  ");
        } while (atual<limite) {
            System.out.print(atual+"  ");
            int proximo=anterior+atual;
            anterior=atual;
            atual=proximo;
        } valorlimite.close();
    }
}