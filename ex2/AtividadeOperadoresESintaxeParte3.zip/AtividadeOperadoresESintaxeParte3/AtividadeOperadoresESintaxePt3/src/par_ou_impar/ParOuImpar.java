package par_ou_impar;

public class ParOuImpar {

	public static void main(String[] args) {
		int x=80;
		
		while(x>1) {
			int y=((x%2)==0)?(x/2):(3*x)+1;
			x=y;
			System.out.println("y = "+y);
		}
	}
}
