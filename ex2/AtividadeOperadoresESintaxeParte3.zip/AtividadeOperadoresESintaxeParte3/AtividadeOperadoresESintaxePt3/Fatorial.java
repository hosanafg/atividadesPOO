public class Fatorial {
    public static void main(String[] args) {
        for (int n=1;n<=5;n++) {
            long fatorial=1;
            for (int i=n;i>=1;i--) {
                fatorial*=i;
            } System.out.println("Fatorial de "+n+"="+fatorial);
        } 
    }
} 